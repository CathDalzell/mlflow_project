.globals <- new.env(parent = emptyenv())
