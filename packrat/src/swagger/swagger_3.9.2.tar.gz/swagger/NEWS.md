# Swagger 3.9.3 (UNRELEASED)

- Adds support for Swagger 3.9.3

# Swagger 3.4.0

- Adds support for Swagger 3.4.0
